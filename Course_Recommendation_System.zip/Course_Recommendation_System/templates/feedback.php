<?php
// feedback.php

// Database connection details
$host = "localhost"; // Change if necessary
$dbname = "coursedb"; // Your database name
$username = "root"; // Your database username
$password = ""; // Your database password

// Create a connection to the MySQL database
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $course_rating = $_POST['course_rating'];
    $feedback = $_POST['feedback'];
    
    // Prepare the SQL statement
    $stmt = "INSERT INTO feed (course_rating, feedback) VALUES ('$course_rating', '$feedback')";

    // Execute the statement and check if it was successful
    if ($conn->query($stmt) == TRUE) {
        echo "Feedback submitted successfully!";
    } else {
        echo "Error: " . $stmt."<br>".$conn->error;
    }
    
    $stmt->close();
}

// Close the connection
$conn->close();
?>
